import React, { useState, createContext } from "react";

export const UserContext = createContext();

export const UserProvider = (props) => {

    const [users, setUsers] = useState([
        { name: "", message: "" },
        { name: "susheel kumar ", message: "Aldus PageMaker including versions of Loreum Ipsum" },


    ]);

    return ( < UserContext.Provider value = {
        [users, setUsers]
    } > { props.children } < /UserContext.Provider>);
};